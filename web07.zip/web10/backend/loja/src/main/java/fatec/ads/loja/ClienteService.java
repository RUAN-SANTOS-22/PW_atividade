package fatec.ads.loja;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
    
    @Autowired
    ClienteRepository bd;
    
    public String gravarCliente(Cliente novo) {
        bd.save(novo);
        return "Cliente gravado com sucesso!";
    }
    
    public Cliente carregarCliente(String email) {
        if(bd.existsById(email)) {
            return bd.findById(email).get();
        } else {
            return new Cliente();
        }
    }
}