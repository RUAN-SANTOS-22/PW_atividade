package fatec.ads.loja;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, String> {
    // Herda os métodos: save(), findById(), existsById(), findAll(), deleteById()
}