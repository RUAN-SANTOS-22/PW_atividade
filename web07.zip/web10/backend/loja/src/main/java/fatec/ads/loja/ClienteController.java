package fatec.ads.loja;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class ClienteController {
    
    @Autowired
    ClienteService service;
    
    @PostMapping("/cliente")
    public String gravar(@RequestBody Cliente novo) {
        return service.gravarCliente(novo);
    }
    
    @GetMapping("/cliente/{email}")
    public Cliente carregar(@PathVariable String email) {
        return service.carregarCliente(email);
    }
}