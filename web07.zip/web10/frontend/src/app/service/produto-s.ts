import { Injectable, inject } from '@angular/core';
import { Produto } from '../model/produto';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProdutoS {
  constructor(private http: HttpClient){}

  public carregarVitrine(): Observable<Produto[]> {
    return this.http.get<Produto[]>("http://localhost:8080/produto/vitrine");
  }

   public gravar(obj: Produto): Observable<String>{
    return this.http.post<String>("http://localhost:8080/produto", obj);
  }

   public carregar(codigo: number): Observable<Produto>{
    return this.http.get<Produto>("http://localhost:8080/produto/"+ codigo);
  }

  public fazerBusca(termo: string): Observable<Produto[]>{   
    return this.http.get<Produto[]>("http://localhost:8080/produto/busca/"+termo);
  }
}
