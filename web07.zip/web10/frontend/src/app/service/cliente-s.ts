import { Injectable } from '@angular/core';
import { Cliente } from '../model/cliente';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ClienteS {
  constructor(private http: HttpClient) {}

  public gravar(obj: Cliente): Observable<String> {
    return this.http.post<String>("http://localhost:8080/cliente", obj);
  }

  public carregar(email: string): Observable<Cliente> {
    return this.http.get<Cliente>("http://localhost:8080/cliente/" + email);
  }
}