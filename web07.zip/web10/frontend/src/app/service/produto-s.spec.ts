import { TestBed } from '@angular/core/testing';

import { ProdutoS } from './produto-s';

describe('ProdutoS', () => {
  let service: ProdutoS;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProdutoS);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
