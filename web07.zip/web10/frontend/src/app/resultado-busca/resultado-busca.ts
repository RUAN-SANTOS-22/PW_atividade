import { Component } from '@angular/core';
import { ProdutoS } from '../service/produto-s';
import { Produto } from '../model/produto';
import { ItemCesta } from '../model/item-cesta';
@Component({
  selector: 'app-resultado-busca',
  imports: [],
  templateUrl: './resultado-busca.html',
  styleUrl: './resultado-busca.css',
})
export class ResultadoBusca {
  mensagem:String="";
  termoBusca: any = {"termo":""};
   lista : Produto[] = []; 

  constructor(private service: ProdutoS){}

  ngOnInit(){
    let json = localStorage.getItem("termoBusca");
    this.mensagem = "";
    if(json!=null){
      this.termoBusca = JSON.parse(json);
      this.service.fazerBusca(this.termoBusca.termo).subscribe({
          next:(data) => {
            this.lista = data;
            if (this.lista.length === 0) {
              this.mensagem = "Nada encontrado para o termo:"+ this.termoBusca.termo;
            } else {
              this.mensagem = "resultado para o termo:"+ this.termoBusca.termo;
            }
          },
          error:(err) => console.error('Erro ao carregar usuários', err)
        }); 

     // 
    }
  }

    redirecionar(obj:Produto){
      localStorage.setItem("ProdutoSelecionado", JSON.stringify(obj));
      location.href="detalhe";
    }

    adicionarItemCesta(obj:Produto){
        let json = localStorage.getItem("cesta");
        let lista : ItemCesta[] = [];
        let item : ItemCesta = new ItemCesta();
        item.produto = obj;
        item.quantidade = 1;
        item.valor = obj.valor;

        if(json!=null){
           lista = JSON.parse(json);
        }
        lista.push(item); 
        localStorage.setItem("cesta", JSON.stringify(lista)); 
        location.href = "cesta";
    }
}
