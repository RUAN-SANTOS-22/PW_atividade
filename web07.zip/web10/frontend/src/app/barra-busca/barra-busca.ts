import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-barra-busca',
  imports: [CommonModule, FormsModule],
  templateUrl: './barra-busca.html',
  styleUrl: './barra-busca.css',
})
export class BarraBusca {
  mensagem: string = "";      // string minúsculo (era String)
  termoBusca: any = {"termo":""};

  buscar(){
    console.log("Teste");
    if(this.termoBusca.termo.length<=3){
      this.mensagem = "A busca precisa ter no minimo 3 caracteres!";
    } else {
      localStorage.setItem("termoBusca", JSON.stringify(this.termoBusca));
      location.href = "busca";
    }
  }
}