import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItemCesta } from '../model/item-cesta';
import { ProdutoS} from '../service/produto-s';
import { Produto } from '../model/produto';

@Component({
  selector: 'app-vitrine',
  imports: [CommonModule],
  templateUrl: './vitrine.html',
  styleUrl: './vitrine.css',
})
export class Vitrine implements OnInit {
    mensagem: string = "";
    lista : Produto[] = []; 
      constructor(private service:ProdutoS){}

      ngOnInit(): void {
        console.log("Carrregou ???");
        this.service.carregarVitrine().subscribe({
          next:(data) => this.lista = data,
          error:(err) => console.error('Erro ao carregar usuários', err)
        }); 
    }


    redirecionar(obj:Produto){
      localStorage.setItem("ProdutoSelecionado", JSON.stringify(obj));
      location.href="detalhe";
    }

    adicionarItemCesta(obj:Produto){
        let json = localStorage.getItem("cesta");
        let lista : ItemCesta[] = [];
        let item : ItemCesta = new ItemCesta();
        item.produto = obj;
        item.quantidade = 1;
        item.valor = obj.valor;

        if(json!=null){
           lista = JSON.parse(json);
        }
        lista.push(item); 
        localStorage.setItem("cesta", JSON.stringify(lista)); 
        location.href = "cesta";
    }
}
