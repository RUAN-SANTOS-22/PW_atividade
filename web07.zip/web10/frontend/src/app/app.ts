import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Bemvindo } from './bemvindo/bemvindo';
import { BarraBusca } from './barra-busca/barra-busca';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Bemvindo, BarraBusca],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('web02');
}
