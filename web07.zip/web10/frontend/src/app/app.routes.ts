import { Routes } from '@angular/router';
import { Contato } from './contato/contato';
import { Vitrine } from './vitrine/vitrine';
import { Cesta } from './cesta/cesta';
import { Detalhe } from './detalhe/detalhe';
import { Cadastro } from './cadastro/cadastro';
import { Login } from './login/login';
import { Recupera } from './recupera/recupera';
import { ResultadoBusca } from './resultado-busca/resultado-busca';

export const routes: Routes = [
    {path:"contato", component:Contato},
    {path:"fale-conosco", component:Contato},
    {path:"", component:Vitrine},
    {path:"vitrine", component:Vitrine},
    {path:"cesta", component:Cesta},
    {path:"detalhe", component:Detalhe},
    {path:"cadastro", component:Cadastro},
    {path:"login",component:Login},
    {path:"recupera",component:Recupera},
    {path:"busca",component:ResultadoBusca}
];
