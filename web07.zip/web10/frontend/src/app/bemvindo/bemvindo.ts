import { Component } from '@angular/core';
import { Cliente } from '../model/cliente';

@Component({
  selector: 'app-bemvindo',
  imports: [],
  templateUrl: './bemvindo.html',
  styleUrl: './bemvindo.css',
})
export class Bemvindo {
  mensagem:string="Ola, faça seu login!";
  obj: Cliente = new Cliente();

  ngOnInit(){
      /*let json = localStorage.getItem("Cliente");
      if(json != null){
        this.obj = JSON.parse(json);
        this.mensagem = "Ola, "+ this.obj.nome + " seja bem vindo, clique aqui para sair";
      } else {
        this.mensagem="Ola, faça seu login!";
      }*/
  }

}
