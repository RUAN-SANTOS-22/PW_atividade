import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';
import { ClienteS } from '../service/cliente-s';

@Component({
  selector: 'app-cadastro',
  imports: [CommonModule, FormsModule],
  templateUrl: './cadastro.html',
  styleUrl: './cadastro.css',
})
export class Cadastro {
  mensagem: string = "";      // string minúsculo
  obj: Cliente = new Cliente();

  constructor(private service: ClienteS) {}

  ngOnInit() {
    let json = localStorage.getItem("Cliente");
    if (json != null) {
      this.obj = JSON.parse(json);
    }
  }

  cadastrar() {
    this.service.gravar(this.obj).subscribe({
      next: (data) => {
        this.mensagem = String(data);
        localStorage.setItem("Cliente", JSON.stringify(this.obj));
        setTimeout(() => {
          this.mensagem = "";
        }, 2000);
      },
      error: (err) => {
        console.error('Erro ao cadastrar', err);
        this.mensagem = "Erro ao cadastrar cliente!";
      }
    });
  }
}