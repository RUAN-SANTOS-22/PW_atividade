import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';
import { ClienteS } from '../service/cliente-s';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  mensagem: string = "";      // string minúsculo
  obj: Cliente = new Cliente();

  constructor(private service: ClienteS) {}

  fazerLogin() {
    this.service.carregar(this.obj.email).subscribe({
      next: (cliente) => {
        if (cliente && cliente.email && cliente.senha === this.obj.senha) {
          this.obj.nome = cliente.nome;
          this.obj.logradouro = cliente.logradouro;
          this.obj.telefone = cliente.telefone;
          this.obj.documento = cliente.documento;
          localStorage.setItem("Cliente", JSON.stringify(this.obj));
          location.href = "cadastro";
        } else {
          localStorage.removeItem("Cliente");
          this.mensagem = "Email ou senha incorretos!";
        }
      },
      error: (err) => {
        console.error('Erro ao carregar cliente', err);
        this.mensagem = "Email ou senha incorretos!";
        localStorage.removeItem("Cliente");
      }
    });
  }

  novoCadastro() {
    localStorage.removeItem("Cliente");
    location.href = "cadastro";
  }
}