package fatec.ads.loja;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    // Buscar cliente por email (útil para login)
    @Query("SELECT c FROM Cliente c WHERE c.email = :email")
    public Cliente buscarPorEmail(@Param("email") String email);

    // Buscar clientes ativos
    @Query("SELECT c FROM Cliente c WHERE c.ativo = 1")
    public List<Cliente> buscarAtivos();

    // Buscar cliente por CPF
    @Query("SELECT c FROM Cliente c WHERE c.cpf = :cpf")
    public Cliente buscarPorCpf(@Param("cpf") String cpf);

    // Busca por nome (like)
    @Query("SELECT c FROM Cliente c WHERE c.nome LIKE :nome")
    public List<Cliente> buscarPorNome(@Param("nome") String nome);
}