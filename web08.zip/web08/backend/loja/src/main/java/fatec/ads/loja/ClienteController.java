package fatec.ads.loja;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class ClienteController {

    @Autowired
    ClienteRepository bd;

    // GET - Buscar cliente por código
    @GetMapping("/cliente/{id}")
    public Cliente carregar(@PathVariable int id) {
        if (bd.existsById(id)) {
            return bd.findById(id).get();
        } else {
            return new Cliente();
        }
    }

    // GET - Listar todos os clientes
    @GetMapping("/clientes")
    public List<Cliente> listar() {
        return bd.findAll();
    }

    // GET - Listar apenas clientes ativos
    @GetMapping("/clientes/ativos")
    public List<Cliente> listarAtivos() {
        return bd.buscarAtivos();
    }

    // GET - Buscar cliente por email
    @GetMapping("/cliente/email/{email}")
    public Cliente buscarPorEmail(@PathVariable String email) {
        Cliente cliente = bd.buscarPorEmail(email);
        if (cliente != null) {
            return cliente;
        } else {
            return new Cliente();
        }
    }

    // GET - Buscar cliente por CPF
    @GetMapping("/cliente/cpf/{cpf}")
    public Cliente buscarPorCpf(@PathVariable String cpf) {
        Cliente cliente = bd.buscarPorCpf(cpf);
        if (cliente != null) {
            return cliente;
        } else {
            return new Cliente();
        }
    }

    // GET - Buscar clientes por nome (contém)
    @GetMapping("/cliente/busca/{termo}")
    public List<Cliente> buscarPorNome(@PathVariable String termo) {
        return bd.buscarPorNome("%" + termo + "%");
    }

    // POST - Inserir novo cliente
    @PostMapping("/cliente")
    public String gravar(@RequestBody Cliente novo) {
        // Verifica se já existe cliente com mesmo código
        if (bd.existsById(novo.getCodigo())) {
            return "Erro: Já existe cliente com este código!";
        }
        
        // Verifica se CPF já está cadastrado
        Cliente existente = bd.buscarPorCpf(novo.getCpf());
        if (existente != null && existente.getCodigo() != novo.getCodigo()) {
            return "Erro: CPF já cadastrado!";
        }
        
        // Verifica se email já está cadastrado
        existente = bd.buscarPorEmail(novo.getEmail());
        if (existente != null && existente.getCodigo() != novo.getCodigo()) {
            return "Erro: E-mail já cadastrado!";
        }
        
        bd.save(novo);
        return "Cliente gravado com sucesso!";
    }

    // PUT - Alterar cliente existente
    @PutMapping("/cliente")
    public String alterar(@RequestBody Cliente obj) {
        if (bd.existsById(obj.getCodigo())) {
            // Verifica se CPF já está sendo usado por outro cliente
            Cliente clienteCpf = bd.buscarPorCpf(obj.getCpf());
            if (clienteCpf != null && clienteCpf.getCodigo() != obj.getCodigo()) {
                return "Erro: CPF já está cadastrado para outro cliente!";
            }
            
            // Verifica se email já está sendo usado por outro cliente
            Cliente clienteEmail = bd.buscarPorEmail(obj.getEmail());
            if (clienteEmail != null && clienteEmail.getCodigo() != obj.getCodigo()) {
                return "Erro: E-mail já está cadastrado para outro cliente!";
            }
            
            bd.save(obj);
            return "Cliente alterado com sucesso!";
        } else {
            return "Cliente não encontrado!";
        }
    }

    // DELETE - Remover cliente
    @DeleteMapping("/cliente/{id}")
    public String remover(@PathVariable("id") int codigo) {
        if (bd.existsById(codigo)) {
            bd.deleteById(codigo);
            return "Cliente removido com sucesso!";
        } else {
            return "Cliente não encontrado!";
        }
    }
}