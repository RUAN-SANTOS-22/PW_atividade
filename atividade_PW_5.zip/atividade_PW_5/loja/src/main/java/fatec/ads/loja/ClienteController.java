package fatec.ads.loja;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class ClienteController {
    
    @Autowired
    Cliente obj;
    
    @GetMapping("/cliente/{id}")
    public Cliente carregar(@PathVariable int id){
        //TODO Recuperar do banco de dados via ID
        obj.setCodigo(id);
        obj.setNome("João Silva");
        obj.setEmail("joao@email.com");
        obj.setTelefone("(11) 99999-9999");
        obj.setEndereco("Rua Exemplo, 123");
        obj.setCpf("123.456.789-00");
        return obj;
    }
    
    @PostMapping("/cliente")
    public Retorno gravar(@RequestBody Cliente novo){
        //TODO Gravar obj no banco de dados
        var r = new Retorno();
        r.setMensagem("Seu cliente foi gravado com sucesso");
        return r;
    }
    
    @PutMapping("/cliente")
    public Retorno alterar(@RequestBody Cliente cliente){
        //TODO Alterar obj no banco de dados
        var r = new Retorno();
        r.setMensagem("Cliente alterado com sucesso");
        return r;
    }
    
    @DeleteMapping("/cliente/{id}")
    public Retorno deletar(@PathVariable int id){
        //TODO Deletar obj do banco de dados
        var r = new Retorno();
        r.setMensagem("Cliente deletado com sucesso");
        return r;
    }
    
    @GetMapping("/cliente/listar")
    public List<Cliente> listarClientes(){
        //TODO Recuperar lista do banco de dados
        return new ArrayList<Cliente>();
    }
}