package fatec.ads.loja;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class PedidoController {
    
    @Autowired
    Pedido obj;
    
    @GetMapping("/pedido/{numero}")
    public Pedido carregar(@PathVariable int numero){
        //TODO Recuperar do banco de dados via numero do pedido
        obj.setNumero(numero);
        obj.setDataPedido(LocalDateTime.now());
        obj.setStatus("Pendente");
        obj.setValorTotal(0.0);
        return obj;
    }
    
    @PostMapping("/pedido")
    public Retorno gravar(@RequestBody Pedido novo){
        //TODO Gravar obj no banco de dados
        var r = new Retorno();
        r.setMensagem("Seu pedido foi gravado com sucesso");
        return r;
    }
    
    @PutMapping("/pedido/{numero}/status")
    public Retorno atualizarStatus(@PathVariable int numero, @RequestBody String status){
        //TODO Atualizar status do pedido no banco de dados
        var r = new Retorno();
        r.setMensagem("Status do pedido " + numero + " atualizado para: " + status);
        return r;
    }
    
    @GetMapping("/pedido/cliente/{clienteId}")
    public List<Pedido> listarPedidosCliente(@PathVariable int clienteId){
        //TODO Recuperar pedidos do cliente do banco de dados
        return new ArrayList<Pedido>();
    }
    
    @GetMapping("/pedido/status/{status}")
    public List<Pedido> listarPedidosPorStatus(@PathVariable String status){
        //TODO Recuperar pedidos por status do banco de dados
        return new ArrayList<Pedido>();
    }
}